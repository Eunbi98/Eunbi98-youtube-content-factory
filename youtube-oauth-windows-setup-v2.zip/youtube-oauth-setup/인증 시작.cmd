@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_LAUNCHER=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 goto missing_python
  set "PYTHON_LAUNCHER=python"
)
%PYTHON_LAUNCHER% -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
if errorlevel 1 goto missing_python
if not exist ".venv\Scripts\python.exe" (
  %PYTHON_LAUNCHER% -m venv .venv
  if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe authorize_youtube.py
if errorlevel 1 goto failed
echo.
echo 인증이 완료되었습니다. 열린 폴더의 JSON 파일은 비밀로 보관해주세요.
pause
exit /b 0
:missing_python
echo Python 3.10 이상을 먼저 설치해주세요: https://www.python.org/downloads/windows/
echo 설치 화면에서 Add python.exe to PATH를 선택한 뒤 이 파일을 다시 실행하세요.
pause
exit /b 1
:failed
echo.
echo 완료하지 못했습니다. 위 안내를 확인해주세요. JSON이나 토큰 내용은 채팅에 올리지 마세요.
pause
exit /b 1
