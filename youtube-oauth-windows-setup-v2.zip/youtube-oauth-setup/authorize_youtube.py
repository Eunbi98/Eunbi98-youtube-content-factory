"""Desktop-only YouTube upload consent. Does not upload or publish videos."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import sys
import uuid
from datetime import datetime

UPLOAD_SCOPE = 'https://www.googleapis.com/auth/youtube.upload'

class SetupError(Exception):
    pass

def load_desktop_client(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        raise SetupError('JSON 파일을 읽지 못했습니다. Google Cloud에서 다운로드한 파일을 선택해주세요.') from None
    client = data.get('installed') if isinstance(data, dict) else None
    if not isinstance(client, dict) or not client.get('client_id') or not client.get('client_secret'):
        raise SetupError('데스크톱 앱 유형의 OAuth JSON이 아닙니다. Google Cloud에서 앱 유형을 확인해주세요.')
    # Keep the SDK on Google's official endpoints, regardless of selected file contents.
    if client.get('auth_uri') != 'https://accounts.google.com/o/oauth2/auth' or client.get('token_uri') != 'https://oauth2.googleapis.com/token':
        raise SetupError('Google 공식 인증 주소가 들어 있는 원본 JSON을 선택해주세요.')
    return {'installed': client}

def choose_client() -> Path:
    try:
        import tkinter as tk
        from tkinter.filedialog import askopenfilename
        window = tk.Tk(); window.withdraw()
        try:
            selected = askopenfilename(title='Google Cloud에서 받은 OAuth JSON 선택', initialdir=str(Path.home()/'Downloads'), filetypes=[('Google OAuth JSON', '*.json')])
        finally:
            window.destroy()
    except Exception:
        raise SetupError('파일 선택 창을 열지 못했습니다. python authorize_youtube.py --client "JSON파일경로" 명령으로 실행해주세요.') from None
    if not selected:
        raise SetupError('파일 선택을 취소했습니다. 인증 정보는 저장하지 않았습니다.')
    return Path(selected)

def save_refresh_credentials(client: dict, refresh_token: str, folder: Path | None = None) -> Path:
    if not refresh_token:
        raise SetupError('갱신 토큰이 발급되지 않았습니다. 권한을 허용한 뒤 다시 인증해주세요.')
    # Defaults to the private user profile, outside the downloaded tools/repository.
    folder = folder or Path.home()/'.youtube-content-factory'
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    name = 'youtube-oauth-secrets-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6] + '.json'
    output = folder/name
    values = {'YOUTUBE_CLIENT_ID': client['client_id'], 'YOUTUBE_CLIENT_SECRET': client['client_secret'], 'YOUTUBE_REFRESH_TOKEN': refresh_token}
    fd = os.open(str(output), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(values, handle, ensure_ascii=False, indent=2)
            handle.write('\n')
    except BaseException:
        output.unlink(missing_ok=True)
        raise
    return output

def main() -> int:
    parser = argparse.ArgumentParser(description='YouTube 업로드 권한 인증 전용 도구. 영상은 업로드하지 않습니다.')
    parser.add_argument('--client', type=Path, help='다운로드한 데스크톱 OAuth JSON 경로. 생략하면 파일 선택 창이 열립니다.')
    parser.add_argument('--timeout', type=int, default=1800, help='브라우저 승인 대기시간(초), 기본 1800초/30분')
    args = parser.parse_args()
    if not 60 <= args.timeout <= 3600:
        raise SetupError('대기시간은 60~3600초로 지정해주세요.')
    config = load_desktop_client(args.client or choose_client())
    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
    except ImportError:
        raise SetupError('필요한 패키지가 없습니다. Windows용 인증 시작.cmd로 실행해주세요.') from None
    print('브라우저에서 채널을 관리하는 Google 계정으로 로그인하고 업로드 권한을 허용하세요.')
    print('여러 채널이 있으면 업로드할 채널을 선택하세요. 이 도구는 영상을 업로드하지 않습니다.')
    print(f'최대 {args.timeout // 60}분 동안 기다립니다. 이 창을 닫지 말고, 이번 실행에서 새로 열린 브라우저를 이용하세요.')
    flow = InstalledAppFlow.from_client_config(config, scopes=[UPLOAD_SCOPE])
    try:
        credentials = flow.run_local_server(host='localhost', bind_addr='127.0.0.1', port=0, open_browser=True, timeout_seconds=args.timeout,
            authorization_prompt_message='새로 열린 브라우저에서 인증을 진행하세요. 인증이 끝날 때까지 이 창을 닫지 마세요.',
            success_message='YouTube 권한 인증이 끝났습니다. 이 탭을 닫고 인증 프로그램 창으로 돌아가세요.',
            access_type='offline', prompt='consent')
    except Exception as error:
        if type(error).__name__ == 'WSGITimeoutError':
            raise SetupError('브라우저의 승인 결과가 대기시간 안에 돌아오지 않았습니다. 예전 인증 탭을 닫고 이 도구를 다시 실행한 뒤, 새로 열린 탭에서 진행해주세요. 프로그램 창은 계속 열어두세요.') from None
        raise
    output = save_refresh_credentials(config['installed'], credentials.refresh_token)
    print('\n인증 정보를 본인 컴퓨터에 저장했습니다. 영상은 업로드하지 않았습니다.')
    print('저장 위치:', output)
    print('이 파일이나 원본 JSON을 채팅, GitHub, 공유 드라이브에 올리지 마세요.')
    print('다음 단계: 클라우드 환경 설정에 위 파일의 항목들을 안전하게 등록합니다.')
    if sys.platform == 'win32':
        try: os.startfile(str(output.parent))
        except OSError: pass
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except SetupError as error:
        print('안내:', error, file=sys.stderr)
        raise SystemExit(1)
    except KeyboardInterrupt:
        print('인증을 취소했습니다.', file=sys.stderr)
        raise SystemExit(1)
    except Exception as error:
        # OAuth exceptions may contain codes/tokens; never print their message or traceback.
        print('인증을 완료하지 못했습니다. 오류 종류: '+type(error).__name__, file=sys.stderr)
        print('테스트 사용자 등록, 올바른 Google 계정, 권한 허용과 인터넷 연결을 확인해주세요. 토큰/JSON 내용은 공유하지 마세요.', file=sys.stderr)
        raise SystemExit(1)
